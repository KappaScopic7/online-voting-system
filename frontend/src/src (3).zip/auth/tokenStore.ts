const KEY = 'accessToken';

export function getToken(): string | null {
    return localStorage.getItem(KEY);
}

export function setToken(token: string) {
    localStorage.setItem(KEY, token);
}

export function clearToken() {
    localStorage.removeItem(KEY);
}
