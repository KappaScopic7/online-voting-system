package com.bteam.ovs.voting.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bteam.ovs.voting.model.Vote;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface VoteRepository extends JpaRepository<Vote, UUID> {
    @Query("""
        select v.candidateId as candidateId, count(v) as cnt
        from VoteEntity v
        where v.electionId = :electionId
        group by v.candidateId
    """)
    List<VoteCount> countByElectionGroupByCandidate(@Param("electionId") UUID electionId);

    interface VoteCount {
        UUID getCandidateId();
        long getCnt();
    }

    Optional<Vote> findByElectionIdAndCitizenId(UUID electionId, UUID citizenId);

    List<Vote> findByCitizenIdOrderByCastedAtDesc(UUID citizenId);
}
