package com.bteam.ovs.voting.web;

import com.bteam.ovs.shared.errors.ApiException;
import com.bteam.ovs.voting.service.VotingService;
import com.bteam.ovs.voting.web.dto.VoteConfirmRequest;
import com.bteam.ovs.voting.web.dto.VoteHistoryItem;
import com.bteam.ovs.voting.web.dto.VoteStartResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/voter")
public class VotingController {

    private final VotingService votingService;

    public VotingController(VotingService votingService) {
        this.votingService = votingService;
    }

    @GetMapping("/voting/start")
    public ResponseEntity<VoteStartResponse> start(
            @RequestParam String electionId,
            Authentication auth
    ) {
        validateAuth(auth);
        UUID eid;
        try {
            eid = UUID.fromString(electionId);
        } catch (IllegalArgumentException e) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "INVALID_UUID", "ID形式が不正です");
        }
        
        return ResponseEntity.ok(votingService.start(auth.getName(), eid));
    }

    @PostMapping("/voting/confirm")
    public ResponseEntity<VoteHistoryItem> confirm(
            @Valid @RequestBody VoteConfirmRequest req,
            Authentication auth
    ) {
        validateAuth(auth);
        
        UUID eid;
        UUID cid;
        try {
            eid = UUID.fromString(req.electionId());
            cid = UUID.fromString(req.candidateId());
        } catch (IllegalArgumentException e) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "INVALID_UUID", "ID形式が不正です");
        }

        VoteHistoryItem result = votingService.confirm(auth.getName(), eid, cid);
        // 200 OK で結果(履歴アイテム)を返す
        return ResponseEntity.ok(result);
    }

    @GetMapping("/votes")
    public ResponseEntity<List<VoteHistoryItem>> history(Authentication auth) {
        validateAuth(auth);
        return ResponseEntity.ok(votingService.history(auth.getName()));
    }

    private void validateAuth(Authentication auth) {
        if (auth == null || auth.getName() == null) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED", "未ログインです");
        }
    }
}