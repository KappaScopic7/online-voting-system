package com.bteam.ovs.voting.service;

import com.bteam.ovs.auth.repo.PortalAccountRepository;
import com.bteam.ovs.elections.repo.CandidateRepository;
import com.bteam.ovs.elections.repo.ElectionRepository;
import com.bteam.ovs.shared.errors.ApiException;
import com.bteam.ovs.voting.model.VoteCast;
import com.bteam.ovs.voting.model.VoteCurrent;
import com.bteam.ovs.voting.repo.VoteCastRepository;
import com.bteam.ovs.voting.repo.VoteCurrentRepository;
import com.bteam.ovs.voting.web.dto.VoteHistoryItem;
import com.bteam.ovs.voting.web.dto.VoteStartResponse;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.List;
import java.util.UUID;

import java.time.Instant;

@Service
public class VotingService {

    private final PortalAccountRepository portalRepo;
    private final ElectionRepository electionRepo;
    private final CandidateRepository candidateRepo;
    private final VoteCastRepository voteCastRepo;
    private final VoteCurrentRepository voteCurrentRepo;

    public VotingService(
        PortalAccountRepository portalRepo,
        ElectionRepository electionRepo,
        CandidateRepository candidateRepo,
        VoteCastRepository voteCastRepo,
        VoteCurrentRepository voteCurrentRepo
    ) {
        this.portalRepo = portalRepo;
        this.electionRepo = electionRepo;
        this.candidateRepo = candidateRepo;
        this.voteCastRepo = voteCastRepo;
        this.voteCurrentRepo = voteCurrentRepo;
    }

    public VoteStartResponse start(String voterEmail, UUID electionId) {
        var acc = portalRepo.findByEmail(voterEmail)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED", "未ログインです"));

        if (acc.getCitizenId() == null) {
            throw new ApiException(HttpStatus.FORBIDDEN, "IDENTITY_NOT_LINKED", "本人認証が完了していません");
        }

        var election = electionRepo.findById(electionId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "ELECTION_NOT_FOUND", "選挙が存在しません"));

        var candidates = candidateRepo.findByElectionId(electionId).stream()
                .map(c -> new VoteStartResponse.CandidateItem(c.getId(), c.getName()))
                .toList();

        return new VoteStartResponse(election.getId(), election.getTitle(), candidates);
    }

    @org.springframework.transaction.annotation.Transactional
    public VoteHistoryItem confirm(String voterEmail, UUID electionId, UUID candidateId) {
        var acc = portalRepo.findByEmail(voterEmail)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED", "未ログインです"));

        if (acc.getCitizenId() == null) {
            throw new ApiException(HttpStatus.FORBIDDEN, "IDENTITY_NOT_LINKED", "本人認証が完了していません");
        }

        var election = electionRepo.findById(electionId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "ELECTION_NOT_FOUND", "選挙が存在しません"));

        var now = Instant.now();
        boolean withinPeriod = !now.isBefore(election.getStartsAt()) && now.isBefore(election.getEndsAt());
        if (!withinPeriod) {
            throw new ApiException(HttpStatus.FORBIDDEN, "ELECTION_NOT_ONGOING", "投票可能期間外です");
        }

        if (!candidateRepo.existsByIdAndElectionId(candidateId, electionId)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "INVALID_CANDIDATE", "候補が不正です");
        }

        var candidate = candidateRepo.findById(candidateId)
                .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "INVALID_CANDIDATE", "候補が不正です"));

        // ===== 1) 履歴：追記 =====
        var cast = new com.bteam.ovs.voting.model.VoteCast();
        cast.setElectionId(electionId);
        cast.setCitizenId(acc.getCitizenId());
        cast.setCandidateId(candidateId);
        cast.setCastedAt(now);
        voteCastRepo.save(cast);

        // ===== 2) 最新：upsert（saveでOK） =====
        var current = voteCurrentRepo.findByElectionIdAndCitizenId(electionId, acc.getCitizenId())
                .orElseGet(() -> {
                    var v = new com.bteam.ovs.voting.model.VoteCurrent();
                    v.setElectionId(electionId);
                    v.setCitizenId(acc.getCitizenId());
                    return v;
                });

        current.setCandidateId(candidateId);
        current.setCastedAt(now);
        voteCurrentRepo.save(current);

        // 完了画面：最新票の時刻を返す（now）
        return new VoteHistoryItem(
                cast.getId(),
                election.getId(),
                election.getTitle(),
                candidate.getId(),
                candidate.getName(),
                now
        );
    }
    public List<VoteHistoryItem> history(String voterEmail) {
        var acc = portalRepo.findByEmail(voterEmail)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED", "未ログインです"));

        if (acc.getCitizenId() == null) {
            throw new ApiException(HttpStatus.FORBIDDEN, "IDENTITY_NOT_LINKED", "本人認証が完了していません");
        }

        var votes = voteCastRepo.findByCitizenIdOrderByCastedAtDesc(acc.getCitizenId());
        if (votes.isEmpty()) return List.of();

        var electionIds = votes.stream().map(com.bteam.ovs.voting.model.VoteCast::getElectionId).collect(Collectors.toSet());
        var candidateIds = votes.stream().map(com.bteam.ovs.voting.model.VoteCast::getCandidateId).collect(Collectors.toSet());

        var elections = electionRepo.findAllById(electionIds).stream()
                .collect(Collectors.toMap(e -> e.getId(), Function.identity()));

        var candidates = candidateRepo.findAllById(candidateIds).stream()
                .collect(Collectors.toMap(c -> c.getId(), Function.identity()));

        return votes.stream()
                .map(v -> new VoteHistoryItem(
                        v.getId(),
                        v.getElectionId(),
                        elections.containsKey(v.getElectionId()) ? elections.get(v.getElectionId()).getTitle() : "(unknown election)",
                        v.getCandidateId(),
                        candidates.containsKey(v.getCandidateId()) ? candidates.get(v.getCandidateId()).getName() : "(unknown candidate)",
                        v.getCastedAt()
                ))
                .toList();
    }
}
