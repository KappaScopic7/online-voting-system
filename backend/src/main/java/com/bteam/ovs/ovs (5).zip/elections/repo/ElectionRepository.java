package com.bteam.ovs.elections.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bteam.ovs.elections.model.ElectionEntity;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public interface ElectionRepository extends JpaRepository<ElectionEntity, UUID> {
    java.util.Optional<ElectionEntity> findByTitle(String title);

    List<ElectionEntity> findAllByOrderByStartsAtDesc();

    boolean existsByStartsAtLessThanEqualAndEndsAtGreaterThan(Instant now1, Instant now2);
}
